extends Node3D

const WORLD_SIZE := 48
const MAX_HEIGHT := 14
const BLOCK_SIZE := 1.0
const BLOCK_NAMES := ["Grama", "Terra", "Pedra", "Madeira", "Folhas"]
const BLOCK_COLORS := [Color(0.28, 0.66, 0.22), Color(0.48, 0.30, 0.16), Color(0.48, 0.50, 0.53), Color(0.43, 0.27, 0.12), Color(0.16, 0.48, 0.18)]
var blocks: Dictionary = {}
var world_body: StaticBody3D
var selected_block := 1
var inventory := {0: 0, 1: 32, 2: 16, 3: 12, 4: 0}
var status_label: Label
var inventory_label: Label
var materials: Array[StandardMaterial3D] = []

func _ready() -> void:
	_setup_environment()
	for color in BLOCK_COLORS:
		var mat := StandardMaterial3D.new()
		mat.albedo_color = color
		mat.roughness = 1.0
		materials.append(mat)
	_generate_world()
	_build_world_mesh()
	_create_ui()
	_update_inventory()

func _setup_environment() -> void:
	var env := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_SKY
	environment.sky = Sky.new()
	environment.sky.sky_material = ProceduralSkyMaterial.new()
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	environment.ambient_light_energy = 0.65
	env.environment = environment
	add_child(env)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55, -35, 0)
	sun.light_energy = 1.1
	add_child(sun)

func _generate_world() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 481516
	for x in range(WORLD_SIZE):
		for z in range(WORLD_SIZE):
			var h := int(4 + 2.0 * sin(float(x) * 0.19) + 1.7 * cos(float(z) * 0.16) + 1.0 * sin(float(x + z) * 0.11))
			h = clampi(h, 2, MAX_HEIGHT - 3)
			for y in range(h - 3):
				blocks[Vector3i(x, y, z)] = 2
			for y in range(h - 3, h):
				blocks[Vector3i(x, y, z)] = 1
			blocks[Vector3i(x, h, z)] = 0
			if x > 3 and z > 3 and x < WORLD_SIZE - 4 and z < WORLD_SIZE - 4 and rng.randf() < 0.018 and h >= 3:
				_add_tree(x, h + 1, z)

func _add_tree(x: int, y: int, z: int) -> void:
	for i in range(4):
		blocks[Vector3i(x, y + i, z)] = 3
	for dx in range(-2, 3):
		for dz in range(-2, 3):
			for dy in range(2, 5):
				if abs(dx) + abs(dz) + abs(dy - 3) <= 4 and not blocks.has(Vector3i(x + dx, y + dy, z + dz)):
					blocks[Vector3i(x + dx, y + dy, z + dz)] = 4

func _build_world_mesh() -> void:
	if is_instance_valid(world_body):
		world_body.queue_free()
	world_body = StaticBody3D.new()
	world_body.name = "VoxelTerrain"
	add_child(world_body)
	var surfaces: Array = []
	for i in range(BLOCK_COLORS.size()):
		surfaces.append({"vertices": PackedVector3Array(), "normals": PackedVector3Array(), "indices": PackedInt32Array()})
	var face_data := [
		{"n": Vector3(0,1,0), "v": [Vector3(0,1,0),Vector3(0,1,1),Vector3(1,1,1),Vector3(1,1,0)]},
		{"n": Vector3(0,-1,0), "v": [Vector3(0,0,1),Vector3(0,0,0),Vector3(1,0,0),Vector3(1,0,1)]},
		{"n": Vector3(0,0,1), "v": [Vector3(0,0,1),Vector3(1,0,1),Vector3(1,1,1),Vector3(0,1,1)]},
		{"n": Vector3(0,0,-1), "v": [Vector3(1,0,0),Vector3(0,0,0),Vector3(0,1,0),Vector3(1,1,0)]},
		{"n": Vector3(1,0,0), "v": [Vector3(1,0,1),Vector3(1,0,0),Vector3(1,1,0),Vector3(1,1,1)]},
		{"n": Vector3(-1,0,0), "v": [Vector3(0,0,0),Vector3(0,0,1),Vector3(0,1,1),Vector3(0,1,0)]}
	]
	var neighbor_dirs := [Vector3i(0,1,0),Vector3i(0,-1,0),Vector3i(0,0,1),Vector3i(0,0,-1),Vector3i(1,0,0),Vector3i(-1,0,0)]
	for pos in blocks.keys():
		var block_type: int = blocks[pos]
		var data: Dictionary = surfaces[block_type]
		var base_index: int = data.vertices.size()
		for face_index in range(6):
			if blocks.has(pos + neighbor_dirs[face_index]):
				continue
			var face: Dictionary = face_data[face_index]
			for vertex in face.v:
				data.vertices.append((Vector3(pos) + vertex) * BLOCK_SIZE)
				data.normals.append(face.n)
			data.indices.append_array(PackedInt32Array([base_index, base_index+1, base_index+2, base_index, base_index+2, base_index+3]))
			base_index += 4
		surfaces[block_type] = data
	var mesh := ArrayMesh.new()
	for i in range(surfaces.size()):
		var data: Dictionary = surfaces[i]
		if data.vertices.is_empty():
			continue
		var arrays := []
		arrays.resize(Mesh.ARRAY_MAX)
		arrays[Mesh.ARRAY_VERTEX] = data.vertices
		arrays[Mesh.ARRAY_NORMAL] = data.normals
		arrays[Mesh.ARRAY_INDEX] = data.indices
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
		mesh.surface_set_material(mesh.get_surface_count() - 1, materials[i])
	var visual := MeshInstance3D.new()
	visual.mesh = mesh
	world_body.add_child(visual)
	if mesh.get_surface_count() > 0:
		var collision := CollisionShape3D.new()
		collision.shape = mesh.create_trimesh_shape()
		world_body.add_child(collision)

func interact(place: bool) -> void:
	var player := get_node_or_null("Player")
	if player == null:
		return
	var camera: Camera3D = player.get_node("Head/Camera3D")
	var from := camera.global_position
	var to := from + -camera.global_transform.basis.z * 6.0
	var query := PhysicsRayQueryParameters3D.create(from, to)
	query.exclude = [player.get_rid()]
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	if hit.is_empty():
		return
	var point: Vector3 = hit.position
	var normal: Vector3 = hit.normal
	var cell: Vector3i
	if place:
		cell = Vector3i(floori(point.x + normal.x * 0.51), floori(point.y + normal.y * 0.51), floori(point.z + normal.z * 0.51))
		if blocks.has(cell) or inventory.get(selected_block, 0) <= 0:
			return
		blocks[cell] = selected_block
		inventory[selected_block] -= 1
	else:
		cell = Vector3i(floori(point.x - normal.x * 0.02), floori(point.y - normal.y * 0.02), floori(point.z - normal.z * 0.02))
		if not blocks.has(cell):
			return
		var removed_type: int = blocks[cell]
		blocks.erase(cell)
		inventory[removed_type] = mini(inventory.get(removed_type, 0) + 1, 99)
	_build_world_mesh()
	_update_inventory()

func select_block(index: int) -> void:
	selected_block = clampi(index, 0, BLOCK_COLORS.size() - 1)
	_update_inventory()

func _create_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	layer.add_child(root)
	status_label = Label.new()
	status_label.text = "BLOCK SURVIVAL  •  Sobreviva e construa"
	status_label.position = Vector2(18, 14)
	status_label.add_theme_font_size_override("font_size", 20)
	root.add_child(status_label)
	inventory_label = Label.new()
	inventory_label.position = Vector2(18, 48)
	inventory_label.add_theme_font_size_override("font_size", 17)
	root.add_child(inventory_label)
	var help := Label.new()
	help.text = "PC: WASD + mouse | Espaço pula | Clique esquerdo minera | Direito constrói | 1-5 seleciona"
	help.anchor_left = 0.5
	help.anchor_top = 1.0
	help.anchor_right = 0.5
	help.anchor_bottom = 1.0
	help.position = Vector2(-290, -28)
	help.add_theme_font_size_override("font_size", 13)
	root.add_child(help)
	_add_hold_button(root, "↑", Vector2(92, -166), "move_forward")
	_add_hold_button(root, "↓", Vector2(92, -76), "move_back")
	_add_hold_button(root, "←", Vector2(20, -121), "move_left")
	_add_hold_button(root, "→", Vector2(164, -121), "move_right")
	_add_action_button(root, "PULAR", Vector2(-120, -170), "jump")
	_add_action_button(root, "MINERAR", Vector2(-120, -112), "mine")
	_add_action_button(root, "COLOCAR", Vector2(-120, -54), "place")
	for i in range(5):
		var b := Button.new()
		b.text = str(i + 1)
		b.custom_minimum_size = Vector2(42, 42)
		b.anchor_left = 0.5
		b.anchor_right = 0.5
		b.anchor_top = 1.0
		b.anchor_bottom = 1.0
		b.position = Vector2(-112 + i * 46, -58)
		b.pressed.connect(select_block.bind(i))
		root.add_child(b)

func _add_hold_button(root: Control, label_text: String, offset: Vector2, action: String) -> void:
	var b := Button.new()
	b.text = label_text
	b.custom_minimum_size = Vector2(64, 64)
	b.anchor_top = 1.0
	b.anchor_bottom = 1.0
	b.position = offset
	b.button_down.connect(func(): Input.action_press(action))
	b.button_up.connect(func(): Input.action_release(action))
	root.add_child(b)

func _add_action_button(root: Control, label_text: String, offset: Vector2, action: String) -> void:
	var b := Button.new()
	b.text = label_text
	b.custom_minimum_size = Vector2(108, 48)
	b.anchor_left = 1.0
	b.anchor_right = 1.0
	b.anchor_top = 1.0
	b.anchor_bottom = 1.0
	b.position = offset
	if action == "jump":
		b.pressed.connect(func(): Input.action_press("jump"); Input.action_release("jump"))
	elif action == "mine":
		b.pressed.connect(func(): interact(false))
	else:
		b.pressed.connect(func(): interact(true))
	root.add_child(b)

func _update_inventory() -> void:
	if inventory_label == null:
		return
	var parts: Array[String] = []
	for i in range(BLOCK_NAMES.size()):
		var marker := "▶ " if i == selected_block else ""
		parts.append(marker + str(i + 1) + ":" + BLOCK_NAMES[i] + " " + str(inventory.get(i, 0)))
	inventory_label.text = "   |   ".join(parts)
