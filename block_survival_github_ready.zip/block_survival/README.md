# Block Survival — protótipo 0.1

Protótipo 3D de sobrevivência e construção em blocos, feito em Godot 4, com foco em Android.

## O que esta versão já tem
- Mundo limitado de 48 x 48 blocos, com relevo procedural e árvores.
- Blocos de grama, terra, pedra, madeira e folhas.
- Mineração e colocação de blocos por mira (raycast).
- Inventário simples com cinco tipos de bloco.
- Personagem em primeira pessoa, gravidade, pulo e colisão.
- Controles na tela e controles de teclado/mouse para testar no PC.

## Abrir e testar no Windows
1. Baixe a versão estável do **Godot 4** em https://godotengine.org/download/windows/ .
2. Extraia este ZIP para uma pasta do computador.
3. Abra o **Godot Project Manager** e clique em **Import**.
4. Selecione a pasta `block_survival` (a pasta que contém `project.godot`).
5. Abra o projeto e pressione **F6** ou **F5** para executar.

## Gerar APK para Android
> Este ZIP contém o projeto-fonte. Ele ainda não é um APK compilado.

### 1. Instalar as ferramentas
1. Instale o **Godot 4** para Windows: https://godotengine.org/download/windows/ .
2. Abra o Godot, entre em **Editor > Manage Export Templates** (ou **Gerenciar modelos de exportação**) e instale os templates da mesma versão do Godot que está usando.
3. Instale o **Android Studio**: https://developer.android.com/studio .
4. No Android Studio, abra **SDK Manager** e instale o Android SDK, Android SDK Platform-Tools, Android SDK Build-Tools e Android SDK Command-line Tools. Instale também os componentes recomendados pela documentação da sua versão do Godot.

### 2. Configurar o Godot
1. No Godot, abra **Editor > Editor Settings > Export > Android**.
2. Configure os caminhos do **Android SDK** e do **Java SDK/JDK**. O Android Studio normalmente instala o JDK integrado; use o caminho indicado pelo próprio Android Studio.
3. Volte ao projeto e abra **Project > Export**.
4. Clique em **Add... > Android**.
5. Em **Package/Unique Name**, use um identificador exclusivo, por exemplo `com.blocksurvival.game`.
6. Para testar no seu próprio celular, uma compilação **Debug** é suficiente. Não é necessário criar uma chave de publicação para esse primeiro teste.

### 3. Exportar e instalar
1. Na janela **Project > Export**, selecione o preset Android.
2. Clique em **Export Project**, escolha um local e salve como `BlockSurvival.apk`.
3. Copie o APK para o Samsung Galaxy A55 (USB, Google Drive ou outro meio confiável).
4. No celular, abra o APK pelo app **Meus Arquivos** e autorize a instalação dessa fonte quando o Android solicitar.

Se o Godot mostrar erro de SDK, JDK ou templates, confira se os caminhos estão corretos e se os templates correspondem exatamente à versão instalada do Godot.

## Controles
- PC: WASD para andar, mouse para olhar, espaço para pular, clique esquerdo para minerar e direito para colocar.
- Android: botões na tela para andar, arraste no lado direito para olhar, e botões para pular/minerar/colocar.
- Teclas 1 a 5 ou botões numerados selecionam o bloco.

## Limitações desta versão
É uma primeira versão de base. Ainda não há inimigos, fome, receitas de crafting, salvamento de mundo ou áudio. O mundo é recriado ao iniciar. O APK precisa ser exportado com as ferramentas Android instaladas em um computador.

## Compilar APK pela nuvem com GitHub Actions
Este projeto inclui `.github/workflows/android-apk.yml` e `export_presets.cfg` para tentar gerar um APK de depuração na nuvem, sem instalar Godot/Android Studio no seu aparelho.

1. Crie um repositório **público** no GitHub chamado `block-survival`.
2. Envie para a raiz do repositório todos os arquivos desta pasta, incluindo a pasta oculta `.github`.
3. Abra a aba **Actions**, selecione **Build Android APK** e toque em **Run workflow** (ou faça um push na branch `main`).
4. Quando a execução terminar com sucesso, abra a execução e baixe o artefato `BlockSurvival-APK` na seção **Artifacts**.

O workflow usa a imagem `barichello/godot-ci:4.3`, que fornece Godot, templates de exportação e ferramentas Android. A compilação só será considerada concluída se o GitHub Actions terminar sem erros e disponibilizar o artefato APK. Este APK de depuração é para teste, não uma versão pronta para publicação na Play Store.
